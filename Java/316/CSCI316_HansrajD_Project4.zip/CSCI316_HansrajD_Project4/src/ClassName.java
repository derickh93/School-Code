class ClassName
{
	String id;

	ClassName(String s)
	{
		id = s;
	}
}