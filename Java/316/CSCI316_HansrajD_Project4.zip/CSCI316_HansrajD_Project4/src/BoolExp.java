abstract class BoolExp extends BinaryExp
{
	BoolExp(Exp e1, Exp e2)
	{
		super(e1, e2);
	}
}