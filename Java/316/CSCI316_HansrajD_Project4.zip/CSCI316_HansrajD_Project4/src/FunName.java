import java.util.LinkedList;

class FunName
{
	String id;

	FunName(String s)
	{
		id = s;
	}
	
}