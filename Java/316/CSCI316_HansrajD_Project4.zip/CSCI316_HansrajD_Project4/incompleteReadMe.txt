I was not able to get the program completely working correctly. 

-The following is working on my program:
	-read a text file that contains a string in <class def list>.
	-error messages were not fully implemented
	-eval functions are created in this class and variable identifier class.
	-expanded the symbol table constructed in project 3 to include inherited functions.
	-Each function name is mapped to its parameter list and body expression.
	-Each class object includes a field pointing to the object's function table.
	
-The following is not working on my program:
	-eval function for DotExp is not complete because I was not sure how to implement the algorithm given.
	-the result is not calculated for user defined functions since i was not able to complete the eval function for DotExp
	
	The reason the program is not wokring is because I did not understand how to implement the pseudocode for the eval function in DotExp.
	If I was to be able to get that fixed the code would work as directed. The functions are mapped with their parameter list and body expressions as required.
	
	

