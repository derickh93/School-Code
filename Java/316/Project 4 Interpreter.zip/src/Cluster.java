import java.util.HashMap;

abstract class Cluster extends Statement{
	abstract void printParseTree(String indent);
	//abstract boolean TypeEval(HashMap<String, String> state);
}
