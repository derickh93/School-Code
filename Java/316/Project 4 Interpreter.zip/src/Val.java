
abstract class Val {
	
	abstract Val cloneVal();
	abstract float floatVal();
	abstract boolean isZero();

}
