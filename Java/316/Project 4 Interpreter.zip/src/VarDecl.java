import java.util.HashMap;

abstract class VarDecl{
	
	abstract void printParseTree(String indent);
	abstract void M(HashMap<String, String> state);
	
}
