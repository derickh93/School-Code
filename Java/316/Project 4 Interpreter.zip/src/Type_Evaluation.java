import java.util.*;

public abstract class Type_Evaluation extends ParseTree{
	
	public static HashMap<String, String> state = new HashMap<String, String>();
	
	/*public static void main(String args[]){
		
		setLex(args[0], args[1]);
		
		getToken();
		Program program = program();
		if(!t.isEmpty()){
			displayln(t+" -- unexpected symbol");
		}
		else if(! errorFound){
			program.printParseTree("");
			program.M(state);
		}
		closeIO();
	}*/

}
