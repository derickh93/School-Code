#!/bin/bash
java Parser in1.txt out1.txt
java Parser in2.txt out2.txt
java Parser in3.txt out3.txt
java Parser in4.txt out4.txt
java Parser in5.txt out5.txt
java Parser in6.txt out6.txt

