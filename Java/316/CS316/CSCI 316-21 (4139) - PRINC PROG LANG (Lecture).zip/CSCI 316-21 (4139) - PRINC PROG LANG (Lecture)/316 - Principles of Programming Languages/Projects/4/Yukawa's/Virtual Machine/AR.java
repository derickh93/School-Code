class AR // Activation Record
{
	int base; // index of the bottom of the operand stack segment for this call
	int returnAdd;
}
