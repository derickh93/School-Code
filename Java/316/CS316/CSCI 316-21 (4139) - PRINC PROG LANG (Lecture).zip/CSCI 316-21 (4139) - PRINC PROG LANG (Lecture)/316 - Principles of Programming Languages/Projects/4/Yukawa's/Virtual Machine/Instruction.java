abstract class Instruction
{
	void updateLabel()
	{
	}

	abstract void execute();
}
