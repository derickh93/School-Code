abstract class Elem

// The class of elements to be pushed onto the operand stack "opStack"

{
	abstract Elem cloneElem();
}
