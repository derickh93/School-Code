I was not able to get the program working correctly. 

-The following is working on my program:
	-read a text file that contains a string in <class def list>.
	-eval functions are created in all needed classes
	
-The following is not working on my program:
	-error messages were not fully implemented
	-eval functions are not working as intended

	I was very confused with the lectures when it cames to this project. I am hoping that my work
	 will earn me some credit because I did understand the concept and idea more and more as I attempted 
	to complete more. I am trying my best professor. I did not pass this class last semester which held me 
	back from graduation. I am taking only this one class this semester to graduate. I am doing ok on the 
	homeworks but I am not finding much time to work on the projects. I work 2 full time jobs at
	the moment. I spent most of my time working on the homework this past week because it is worth so much.
