import java.util.*;

class Eq extends CompExp
{
	Eq(Exp e1, Exp e2)
	{
		super(e1, e2);
	}
}