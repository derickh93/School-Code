import java.util.*;

class Floatp extends Exp
{
	float val;
	
	Floatp(float f)
	{
		val = f;
	}

	void semanticCheck()
	{
	}
}