import java.util.*;

class Add extends ArithExp
{
	Add(Exp e1, Exp e2)
	{
		super(e1, e2);
	}
}
