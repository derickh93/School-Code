import java.util.*;

class Or extends BoolExp
{
	Or(Exp e1, Exp e2)
	{
		super(e1, e2);
	}
}