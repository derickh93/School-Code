import java.util.*;

class And extends BoolExp
{
	And(Exp e1, Exp e2)
	{
		super(e1, e2);
	}
}