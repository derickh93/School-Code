import java.util.*;

class Ge extends CompExp
{
	Ge(Exp e1, Exp e2)
	{
		super(e1, e2);
	}
}