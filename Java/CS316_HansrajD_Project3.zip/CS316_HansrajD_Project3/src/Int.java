import java.util.*;

class Int extends Exp
{
	int val;
	
	Int(int i)
	{
		val = i;
	}

	void semanticCheck()
	{
	}
}