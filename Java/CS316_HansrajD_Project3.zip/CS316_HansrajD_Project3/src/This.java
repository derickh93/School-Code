import java.util.*;

class This extends Exp
{	
	static final This thisExp = new This();

	void semanticCheck()
	{
	}
}