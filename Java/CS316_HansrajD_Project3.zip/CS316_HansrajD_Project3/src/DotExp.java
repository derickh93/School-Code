import java.util.*;

class DotExp extends BinaryExp
{
	DotExp(Exp e1, Exp e2)
	{
		super(e1, e2);
	}
}