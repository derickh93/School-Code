import java.util.*;

class Mul extends ArithExp
{
	Mul(Exp e1, Exp e2)
	{
		super(e1, e2);
	}
}
