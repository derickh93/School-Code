import java.util.*;

class Div extends ArithExp
{
	Div(Exp e1, Exp e2)
	{
		super(e1, e2);
	}
}
