class FunName
{
	String id;

	FunName(String s)
	{
		id = s;
	}
}