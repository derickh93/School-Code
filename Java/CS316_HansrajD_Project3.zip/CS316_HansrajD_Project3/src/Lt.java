import java.util.*;

class Lt extends CompExp
{
	Lt(Exp e1, Exp e2)
	{
		super(e1, e2);
	}
}
