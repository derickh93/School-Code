import java.util.*;

class Gt extends CompExp
{
	Gt(Exp e1, Exp e2)
	{
		super(e1, e2);
	}
}