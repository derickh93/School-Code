import java.util.*;

class Le extends CompExp
{
	Le(Exp e1, Exp e2)
	{
		super(e1, e2);
	}
}