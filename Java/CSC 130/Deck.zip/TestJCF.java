package jcf;

// import the library of classes in the java.util package


public class TestJCF {
	public static void main(String[] args){
		// create a List of cards using a LinkedList

		// create a deck

		// shuffle the deck

		// deal 5 cards and add them to the list

		// display the list
		
	}
}
