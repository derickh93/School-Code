package proj4fa16;

public class NewException {

}
