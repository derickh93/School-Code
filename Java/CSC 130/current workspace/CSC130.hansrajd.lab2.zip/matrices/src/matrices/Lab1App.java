package matrices;

public class Lab1App {
	public static void main(String[] args) {
		Matrices m1 = new Matrices(2,2);
		System.out.println(m1.toString());
	}

}
