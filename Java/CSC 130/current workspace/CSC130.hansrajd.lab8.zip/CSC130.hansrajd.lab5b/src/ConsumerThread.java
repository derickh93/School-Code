public class ConsumerThread extends Thread {
	private ArrayQueue<String> queue;
	private ProducerThread producer;
	private int count;
	private PictPanel panel;
	private boolean running;
	// TODO: constructor
	// initialize the queue, producer thread, and the panel
	// using the 3 parameters
	public void run() {
		// TODO loop while the producer thread isAlive or the queue is not empty
		// Note: possible exceptions that can occur are
		// QueueEmptyException and InterruptedException
		{
			// TODO loop while the queue is empty
			// TODO if the queue is not empty
			{
				// take an item from the queue
				// call the panel's drawPict method and pass the item
				// Use Thread.currentThread().getName() to output
				// the name of this thread and the item it processed
				// add 1 to the count
				// sleep for 1000 to 5000 milliseconds (random)
			}
		}
		// TODO When the thread stop's running,
		// display its name and the number of items processed
	}
}