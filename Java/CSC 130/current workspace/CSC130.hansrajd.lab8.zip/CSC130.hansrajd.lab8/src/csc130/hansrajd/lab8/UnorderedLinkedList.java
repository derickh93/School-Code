package csc130.hansrajd.lab8;

public class UnorderedLinkedList <T extends Comparable<T>> extends LinkedList<T> {

	@Override
	public void insert(T insertItem) {
		Node<T> trav = head;
		while(trav.getNext() != null)
			trav = trav.getNext();
		trav.setNext(new Node<T>(insertItem));
		++numItems;
	}

	@Override
	public int search(T searchItem) {
		int location = -1;
		Node<T> trav = head;
		boolean found = false;
		int index = 0;
		while(!found && trav.getNext() != null){
			if(trav.getNext().getData().compareTo(searchItem) == 0) {
				found = true;
			location = index;
		}
		else{
			trav = trav.getNext();
			index++;
		}
	}
		return location;
	}

	@Override
	public T remove(T removeItem) {
		T theData = null;
		Node<T> trav = head;
		boolean found = false;
		while(!found && trav.getNext() != null){
			if(trav.getNext().getData().compareTo(removeItem) == 0) {
				found = true;
				theData = trav.getNext().getData();
				trav.setNext(trav.getNext().getNext());
				--numItems;
		}
		else{
			trav = trav.getNext();
		}
	}
		return theData;
	}

}
