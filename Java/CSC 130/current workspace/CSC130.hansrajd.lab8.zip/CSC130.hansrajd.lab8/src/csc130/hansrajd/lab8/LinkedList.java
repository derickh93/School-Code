package csc130.hansrajd.lab8;

public abstract class LinkedList<T extends Comparable<T>> {
	protected class Node<E> {
		private E data;
		private Node<E> next;
		
		public Node() {
			data = null;
			next = null;
		}
		
		public Node(E d) {
			data = d;
			next = null;
		}
		public Node(E d, Node<E> n) {
			data = d;
			next = n;
		}
		public Node<E> getNext() {
			return next;
		}
		public void setNext(Node<E> n) {
			 next = n;
		}
		public E getData() {
			return data;
		}
		public void setData(E n) {
			 data = n;
		}
	}
	protected Node<T> head = new Node<T>(); //dummy Node
	protected int numItems;
	public abstract void insert(T insertItem);
	public abstract int search(T searchItem);
	public abstract T remove(T removeItem);
	public int getSize(){
		return numItems;
	}
	public boolean isEmpty(){
		return numItems == 0;
	}
	public String toString(){
		String str = "";
		Node<T> trav = head.next;
		while(trav != null) {
			str += trav.data + ((trav.next == null) ? "" : ",");
			trav = trav.next;
		}
		return str;
		
	}
	public void makeEmpty(){
		head = new Node<T>();
		numItems = 0;
		System.gc();
	}
}
