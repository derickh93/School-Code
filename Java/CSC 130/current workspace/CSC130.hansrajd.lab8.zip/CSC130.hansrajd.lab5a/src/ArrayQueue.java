

public class ArrayQueue<T> implements ArrayQueueADT<T> {
	private T[] data;
	private int front, rear, size;
	final int CAPACITY = 100;

	public ArrayQueue() {
		data = (T[]) (new Object[CAPACITY]);
	}

	public ArrayQueue(int s) throws RuntimeException {
		if (s < 1)
			throw new RuntimeException("Invalid queue size exception...");
		data = (T[]) (new Object[s]);
	}

	public synchronized void enqueue(T d) throws RuntimeException {
		if (isFull())
			throw new QueueException("Queue full exception...");
		data[rear] = d;
		rear = (rear + 1) % data.length;
		size++;
	}

	public synchronized T dequeue() throws RuntimeException {
		if (isEmpty())
			throw new QueueException("Queue empty exception...");
		T d = data[front];
		front = (front + 1) % data.length;
		size--;
		return d;
	}

	public synchronized T front() throws RuntimeException {
		if (isEmpty())
			throw new QueueException("Queue empty exception...");
		return data[front];
	}

	public synchronized T rear() throws RuntimeException {
		if (isEmpty())
			throw new QueueException("Queue empty exception...");
		if (isFull())
			return data[size-1];
		else 
			return data[rear-1];
	}

	public synchronized int getSize() {
		return size;
	}

	public synchronized boolean isEmpty() {
		return size == 0;
	}

	public synchronized boolean isFull() {
		return size == data.length;
	}
	public synchronized void makeEmpty() {
		while(!isEmpty()) {
			dequeue();
		}
	}

	public synchronized String toString() {
		String str = new String();
		String s1 = new String();
		int trav = front;
		if(isEmpty())
			s1 = "Queue is empty! Maximum number of items that can be stored is " + data.length;

		for (int i = 0; i < size; i++) {{
			str += data[trav] + ((i < size - 1) ? "," : "");
			trav = (trav + 1) % data.length;
		}
		s1 = "The number of items in the queue is: " + getSize() + "\nThe queue "
				+ "contains the following: \n" + str;
		}
		return  s1;
	}
}