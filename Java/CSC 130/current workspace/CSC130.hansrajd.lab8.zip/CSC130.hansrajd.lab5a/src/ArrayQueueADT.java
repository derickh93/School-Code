

public interface ArrayQueueADT<T> {
	void enqueue(T d) throws RuntimeException;

	T dequeue() throws RuntimeException;

	T front() throws RuntimeException;

	int getSize();

	boolean isEmpty();

	boolean isFull();
}