package proj4fa16;
import java.io.FileNotFoundException;

public class Proj4App {
	public static void main(String [] args) throws FileNotFoundException {
		UnorderedList l1 = new UnorderedList("tickerCompanyData");
		System.out.println(l1.tickerSearch("ORCL"));

	}

}
