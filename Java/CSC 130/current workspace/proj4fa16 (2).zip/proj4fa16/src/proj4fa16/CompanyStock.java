package proj4fa16;

public class CompanyStock {
	//instance variables
	String tickerSym;
	int numStocks;
	double price;
	
	public CompanyStock(String t1, int n1, double p1) {
		tickerSym = t1;
		numStocks = n1;
		price = p1;
	}

	/**
	 * @return the ticker
	 */
	public String getTicker() {
		return tickerSym;
	}

	/**
	 * @return the numStocks
	 */
	public int getNumStocks() {
		return numStocks;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CompanyStock [ticker=" + tickerSym + ", numStocks=" + numStocks + ", price=" + price + "]";
	}

	/**
	 * @param numStocks the numStocks to set
	 */
	public void setNumStocks(int numStocks) {
		this.numStocks = numStocks;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
}
