package proj4fa16;
import java.util.*;
import java.io.*;

public class UnorderedList extends CompanyInfo{
	ArrayUnorderedList <CompanyInfo>list1 = new ArrayUnorderedList<CompanyInfo>();
	public UnorderedList() {
		super();
	}
	@SuppressWarnings("resource")
	public UnorderedList(String s1) throws FileNotFoundException {
		//creating File instance to reference text file in Java
		File text = new File(s1 + ".txt");

		//Creating Scanner instance to read File in Java
		Scanner scnr = new Scanner(text);

		//Reading each line of file using Scanner class
		String ticker;
		String companyName;
		while(scnr.hasNextLine()){
			String line = scnr.nextLine();
			int pos = line.indexOf(' ');
			ticker = line.substring(0, pos);
			companyName = line.substring(pos);
			list1.addToRear(new CompanyInfo(ticker, companyName));
		}
	}
	public String tickerSearch(String c1) {
		String s1 = new String();
		for(int i = 0; i < list1.size(); i++) {
			if(list1.get(i).getTicker().equals(c1))
				s1 = list1.get(i).getCompany();
		}
		return s1;
	}

}
