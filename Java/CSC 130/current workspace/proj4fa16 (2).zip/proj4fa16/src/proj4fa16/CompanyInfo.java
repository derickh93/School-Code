package proj4fa16;

public class CompanyInfo {
	//instance variables
	String tickerSym;
	String companyName;
	public CompanyInfo() {
		tickerSym = null;
		companyName = null;
	}
	public CompanyInfo(String s1, String s2) {
		tickerSym = s1;
		companyName = s2;
	}
	public String getTicker() {
		return tickerSym;
	}
	public String getCompany() {
		return companyName;
	}
	
}
