package proj4fa16;

public class MyStocks {
	ArrayUnorderedList<UnorderedList> list1 = new ArrayUnorderedList<UnorderedList>();
	double status;
	
	public MyStocks(UnorderedList l1) {
		
	}
	public void transaction(){
		
	}
}
