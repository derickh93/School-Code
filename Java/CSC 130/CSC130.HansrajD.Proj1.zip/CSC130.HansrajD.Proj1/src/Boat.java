
public class Boat extends Vehicle{
	static int count;
	
	public Boat() {
		
	}
	
	public Boat(String manufacturer, String model) {
	}
	
	public void returnVehicle() {
		
	}
	
	public String toString() {
		return null;
		
	}
}
