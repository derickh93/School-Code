
public class Automobile extends Vehicle{
	int mileage;
	static int count;
	
	public Automobile() {
	}
	
	public Automobile(String manufacturer, String model) {
	}
	
	public void returnVehicle() {
		
	}
	public String toString() {
		return null;
		
	}
	

}
