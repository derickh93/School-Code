
public class VehicleApp {
	
	public static void main (String[] args) {
		Vehicle [] v;
	}

}
