

public class LinkedQueue<T> implements LinkedQueueADT<T> {
	private class Node<E> {
		private E data;
		private Node<E> next;

		public Node() {
			data = null;
			next = null;
		}

		public Node(E d) {
			data = d;
			next = null;
		}

		public Node(E d, Node<E> n) {
			data = d;
			next = n;
		}
	}

	private Node<T> front, rear;
	private int size;

	public void enqueue(T d) {
		if (isEmpty())
			front = rear = new Node<T>(d);
		else {
			rear.next = new Node<T>(d);
			rear = rear.next;
		}
		size++;
	}

	public T dequeue() throws RuntimeException {
		if (isEmpty())
			throw new RuntimeException("Queue empty exception...");
		T d = front.data;
		front = front.next;
		if (front == null)
			rear = null;
		size--;
		return d;
	}

	public T front() throws RuntimeException {
		if (isEmpty())
			throw new RuntimeException("Queue empty exception...");
		return front.data;
	}

	public int getSize() {
		return size;
	}

	public boolean isEmpty() {
		return size == 0;
	}

	public String toString() {
		String str = "[";
		Node<T> trav = front;
		while (trav != null) {
			str += trav.data + ((trav.next == null) ? "" : ",");
			trav = trav.next;
		}
		str += "]";
		return str;
	}
}