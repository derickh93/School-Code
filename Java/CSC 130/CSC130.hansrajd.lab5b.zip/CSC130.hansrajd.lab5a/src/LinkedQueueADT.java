

public interface LinkedQueueADT<T> {
	void enqueue(T d);

	T dequeue() throws RuntimeException;

	T front() throws RuntimeException;

	int getSize();

	boolean isEmpty();
}