package batman;

public class BatmanOne {
	public static void main ( String args[]){
		
		System.out.println("I am a Giants Fan!!!!");
		System.out.println("I am a Eagles Fan!!!!");
		System.out.println("I am a Cowboys Fan!!!!");
		System.out.println("I am a Patriots Fan!!!!");
		System.out.println("I am a Seahawks Fan!!!!");
	}

}
