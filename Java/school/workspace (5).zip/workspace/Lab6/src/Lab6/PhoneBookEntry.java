package Lab6;

/***
 * Title: Project 2: Card Game
 * Description: This creates a new Deck, which it then shuffles.
 * It then displays the card on the GUI. Then it displayed the 
 * selected outputs the user has asked for.
 * 
 * @author Derick Hansraj
 *
 */

public class PhoneBookEntry {
	/**creates a public access, non object creating, program that searches  
	 * for the main function with no return type 
	 * 
	 * @param args the argument is passed to the Dice object 
	 */
	public static void main(String[] args) {
		String firstName, lastName, phoneNumber, birthDate, relationship;

			firstName = "None";
			lastName = "None";
			phoneNumber = "516-555-5555";
			birthDate = "01/01/2013";
			relationship = "X";
	}
			
		
		


	}

}
