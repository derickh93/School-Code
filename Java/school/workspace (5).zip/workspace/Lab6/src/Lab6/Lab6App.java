package Lab6;

/***
 * Title: Project 2: Card Game
 * Description: This creates a new Deck, which it then shuffles.
 * It then displays the card on the GUI. Then it displayed the 
 * selected outputs the user has asked for.
 * 
 * @author Derick Hansraj
 *
 */

public class Lab6App {
	/**creates a public access, non object creating, program that searches  
	 * for the main function with no return type 
	 * 
	 * @param args the argument is passed to the Dice object 
	 */

	public static void main(String[] args) {

	}

}
