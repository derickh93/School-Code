package CSC130lib;

public class LinkedQueue<T> {

}
