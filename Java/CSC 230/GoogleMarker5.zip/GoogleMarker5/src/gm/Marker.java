package gm;

public class Marker {
	
	// will need instance variables to store latitude, longitude, color, label, category
	
	

	// will need appropriate parameterized constructor, accessors and mutators
	
	

	// will need toString that outputs in format of ex.
	
	// &markers=color:red%7Clabel:A%7C40.729961,-73.590879
	
	// A is the value of the label
	// there is "%7C" separating the value of the color and the word label
	// there is "%7C" separating the value of the label and the latitude
	
	public String toString() { 
	
		
	}
}
