interface diningServer
{
	public void takeChopsticks(int philNumber);
	public void returnChopsticks(int philNumber);
}