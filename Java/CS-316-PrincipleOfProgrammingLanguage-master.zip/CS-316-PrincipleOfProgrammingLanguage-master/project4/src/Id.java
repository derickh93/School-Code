import java.util.*;

class Id
{
	String id;

	Id(String ident)
	{
		id = ident;
	}

	void printParseTree()
	{
		IO.displayln(" " + id);
	}
}