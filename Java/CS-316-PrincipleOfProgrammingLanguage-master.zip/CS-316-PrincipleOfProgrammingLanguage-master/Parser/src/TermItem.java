
abstract class TermItem 
{
	Term term;
	abstract public void printParseTree(String indent);
}