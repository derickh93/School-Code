
abstract class RightSide 
{
	void printParseTree(String indent) 
	{
		IO.displayln(indent + indent.length() + " <right side>");
	}
}