
public abstract class Primary 
{
	Primary primary;
	abstract void printParseTree(String indent);
}
