package cs316project;

abstract class FunExp extends Exp{

}
