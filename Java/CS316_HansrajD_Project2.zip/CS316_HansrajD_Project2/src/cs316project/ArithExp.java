package cs316project;

public class ArithExp extends BinaryExp{

	ArithOp arithOp;
	Exp expOne;
	Exp expTwo;
	


}
