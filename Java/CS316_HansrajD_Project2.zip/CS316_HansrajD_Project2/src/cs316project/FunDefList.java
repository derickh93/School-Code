package cs316project;

abstract class FunDefList{

}
