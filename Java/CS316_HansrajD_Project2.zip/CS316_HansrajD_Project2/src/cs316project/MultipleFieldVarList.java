package cs316project;

public class MultipleFieldVarList extends FieldVarList{
	
	FieldVar fieldVar;
	FieldVarList fieldVarList;
	
	MultipleFieldVarList(FieldVar fieldVar, FieldVarList fieldVarList) {
		this.fieldVar = fieldVar;
		this.fieldVarList = fieldVarList;
	}

}
