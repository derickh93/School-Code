package cs316project;

public class EmptyFieldVarList extends FieldVarList{

}
