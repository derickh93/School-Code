package cs316project;

public class ArithOp extends ArithExp{


	String operation;
}
