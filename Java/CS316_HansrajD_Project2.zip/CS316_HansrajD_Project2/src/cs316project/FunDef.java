package cs316project;

public class FunDef extends FunDefList{
	Header header;
	Exp exp;
	FunDef(Header header, Exp exp) {
		this.header = header;
		this.exp = exp;
	}	

}
