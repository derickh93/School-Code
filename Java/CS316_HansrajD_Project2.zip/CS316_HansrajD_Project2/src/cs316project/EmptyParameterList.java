package cs316project;

public class EmptyParameterList extends ParameterList{

}
