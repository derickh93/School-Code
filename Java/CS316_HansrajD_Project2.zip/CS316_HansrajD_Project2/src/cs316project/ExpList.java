package cs316project;

public class ExpList extends FunCall {

	Exp eXP;
	ExpList eXPList;
	
}
