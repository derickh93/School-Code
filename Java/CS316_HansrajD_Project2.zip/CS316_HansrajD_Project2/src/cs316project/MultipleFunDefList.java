package cs316project;

public class MultipleFunDefList extends FunDefList{
	FunDef funDef;
	FunDefList funDefList;
	
	MultipleFunDefList(	FunDef funDef,FunDefList funDefList) {
		this.funDef = funDef;
		this.funDefList = funDefList;
	}


}
