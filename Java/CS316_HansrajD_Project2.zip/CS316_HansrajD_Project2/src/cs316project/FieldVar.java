package cs316project;

public class FieldVar extends FieldVarList{


	FieldVar(String id) {
		this.id = id;
	}

	String id;
	

}
