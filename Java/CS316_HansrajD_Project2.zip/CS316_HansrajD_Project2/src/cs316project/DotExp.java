package cs316project;

public class DotExp extends BinaryExp{

	Exp expOne;
	Exp expTwo;

}
