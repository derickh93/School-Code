package cs316project;

public class Not extends FunExp{


	Exp exp;
}
