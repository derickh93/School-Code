package cs316project;

public class MultipleParameterList extends ParameterList{
	Parameter parameter;
	ParameterList parameterList;
	
	MultipleParameterList(Parameter parameter, ParameterList parameterList) {
		this.parameter = parameter;
		this.parameterList = parameterList;
	}

}
