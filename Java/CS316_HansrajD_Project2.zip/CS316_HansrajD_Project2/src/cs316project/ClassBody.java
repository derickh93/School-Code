package cs316project;

public class ClassBody{

	ClassBody(FieldVarList fvl, FunDefList fdl) {
		this.fieldVarList = fvl;
		this.funDefList = fdl;
	}
	FieldVarList fieldVarList;
	FunDefList funDefList;
	

}
