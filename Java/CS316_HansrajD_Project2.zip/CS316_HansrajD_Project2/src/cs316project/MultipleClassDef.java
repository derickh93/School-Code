package cs316project;

public class MultipleClassDef extends ClassDefList{

	ClassDef classDef;
	ClassDefList classDefList;
	
	MultipleClassDef(ClassDef cd, ClassDefList cdl) {
		this.classDef = cd;
		this.classDefList = cdl;
	}

}
