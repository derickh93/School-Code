package cs316project;

public class Cond extends FunExp{

	Exp expOne;
	Exp expTwo;
	Exp expThree;

}
