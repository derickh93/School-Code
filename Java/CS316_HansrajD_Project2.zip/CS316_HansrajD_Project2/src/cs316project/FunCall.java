package cs316project;

public class FunCall extends FunExp{

	FunName funName;
	ExpList expList;
	
}
