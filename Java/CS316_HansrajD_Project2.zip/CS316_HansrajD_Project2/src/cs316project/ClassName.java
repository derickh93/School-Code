package cs316project;

public class ClassName {
	public String Id;
	
	ClassName(String id){
		Id = id;
	}
}
