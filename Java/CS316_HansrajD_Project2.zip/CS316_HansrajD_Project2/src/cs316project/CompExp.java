package cs316project;

public class CompExp extends BinaryExp{

	CompOp compOp;
	Exp expOne;
	Exp expTwo;
	

}