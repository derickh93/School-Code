package cs316project;

public class EmptyFunDefList extends FunDefList{

}
