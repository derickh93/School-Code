package cs316project;

public class BoolExp extends BinaryExp{

	BoolOp boolOp;
	Exp expOne;
	Exp expTwo;


}