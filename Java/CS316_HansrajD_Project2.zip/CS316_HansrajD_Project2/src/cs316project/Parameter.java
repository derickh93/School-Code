package cs316project;

public class Parameter extends ParameterList{
	String id;
	
	Parameter(String id){
		this.id = id;
	}
}
