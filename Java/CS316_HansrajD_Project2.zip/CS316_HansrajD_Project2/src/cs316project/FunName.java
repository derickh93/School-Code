package cs316project;

public class FunName extends Header{
	String id;
	FunName(String id) {
		this.id = id;
	}

}
