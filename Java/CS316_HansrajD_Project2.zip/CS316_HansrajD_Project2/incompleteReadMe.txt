I was not able to get the program working correctly. 

-The following is working on my program:
	-I created classes to represent empty string
	-read a text file that contains a string in <class def list>.
	-partial completion of explicit parse tree.
	-Creating analogous class schemas for classes that required them by creating abstract classes.
-The following is not working on my program:
	-symbol table was not fully implemented
	-all of the classes are not complete so the first three test files provided are the only ones that work.
	-error messages were not fully implemented

	To be honest I started working on it very late and by the time I understood what to 
do there was not much time left. If you look at my progress on the classes that I did complete 
you can see that I was working my way down the provided EBNF. I was able to get the classes created 
and a partially explicit parse tree developed.I am hoping that my work will earn me some credit as I 
was understanding the concept and idea more and more as I completed classes.