//Derick Hansraj
//11/28/2018
//Homework #6
//Cs211 Lab

#include <iostream>
#include <string>
#include <sstream>
#include "Student.h"
#include "Roster.h"
#include "Date.h"

int main() {


    //creating a roster using the parameterized constructor
    Roster r("CSC","111",4,"Sands");
    //creating two date objects
    Date d1(01,01,2018);
    Date d2(07,12,1993);

    //attempting to add 12 students to the roster.

    Student s("Hansraj","Derick",d2,d1,3.75,120,"0000");
    r.addStudent(s);

    Student s2("Hansraj","Derick",d2,d1,3.75,120,"0001");
    r.addStudent(s2);

    Student s3("Hansraj","Derick",d2,d1,3.75,120,"0002");
    r.addStudent(s3);

    Student s4("Hansraj","Derick",d2,d1,3.75,120,"0003");
    r.addStudent(s4);

    Student s5("Hansraj","Derick",d2,d1,3.75,120,"0004");
    r.addStudent(s5);

    Student s6("Hansraj","Derick",d2,d1,3.75,120,"0005");
    r.addStudent(s6);

    Student s7("Hansraj","Derick",d2,d1,3.75,120,"0006");
    r.addStudent(s7);

    Student s8("Hansraj","Derick",d2,d1,3.75,120,"0007");
    r.addStudent(s8);

    Student s9("Hansraj","Derick",d2,d1,3.75,120,"0008");
    r.addStudent(s9);

    Student s10("Hansraj","Derick",d2,d1,3.75,120,"0009");
    r.addStudent(s10);

    Student s11("Hansraj","Derick",d2,d1,3.75,120,"0010");
    r.addStudent(s11);

    //creating a 12th student object and adding it to the roster.
    Student s12("Manning","Eli",d2,d1,4.00,10,"0123");
    r.addStudent(s12);

    //outputting the roster
    std::cout << "Roster R: \n " << r << endl;

    //creating a second roster
    Roster r2;

    //outputting the roster
    std::cout << "Roster R2: \n " << r2 << endl;

    //setting r2 equal to r
    r2 = r;

    //outputting both r2 and r
    std::cout << "Roster R2: \n " << r2 << endl;
    std::cout << "Roster R: \n " << r << endl;


    //attempting to add 11 students to the roster.

    Student s13("Hansraj","Derick",d2,d1,3.75,120,"0011");
    r.addStudent(s13);

    Student s14("Hansraj","Derick",d2,d1,3.75,120,"0012");
    r.addStudent(s14);

    Student s15("Hansraj","Derick",d2,d1,3.75,120,"0013");
    r.addStudent(s15);

    Student s16("Hansraj","Derick",d2,d1,3.75,120,"0014");
    r.addStudent(s16);

    Student s17("Hansraj","Derick",d2,d1,3.75,120,"0015");
    r.addStudent(s17);

    Student s18("Hansraj","Derick",d2,d1,3.75,120,"0016");
    r.addStudent(s18);

    Student s19("Hansraj","Derick",d2,d1,3.75,120,"0017");
    r.addStudent(s19);

    Student s20("Hansraj","Derick",d2,d1,3.75,120,"0018");
    r.addStudent(s20);

    Student s21("Hansraj","Derick",d2,d1,3.75,120,"0019");
    r.addStudent(s21);

    Student s22("Hansraj","Derick",d2,d1,3.75,120,"0020");
    r.addStudent(s22);

    Student s23("Hansraj","Derick",d2,d1,3.75,120,"0021");
    r.addStudent(s23);

    //outputting r
    std::cout << "Roster R: \n " << r << endl;

    //setting r2 equal to r
    r2 = r;

    //outputting r2
    std::cout << "Roster R2: \n " << r2 << endl;

	return 0;
}
