//Derick Hansraj
//12/12/2018
//Homework 8
//CS211 Lab

#include <iostream>
#include "File.h"
#include "Image.h"
#include "Text.h"


//main file to test Image, Text, and File class

int main () {
    Text t("testing",39);
    t.display();

    Image i("image",2070,1380,1);
    i.display();

    return 0;
}

