//Derick Hansraj
//12/12/2018
//Homework 8
//CS211 Lab

//CPP file that defines and test recursive functions

#include <iostream>
#include <string>
#include <vector>
#include "File.h"
#include "Image.h"
#include "Text.h"

//Helper Recursive Functions
void displayFile (const std::vector<File*>& files);
std::vector<File*> fileSeperate (const std::vector<File*>& files, std::string type);

//Recursive Functions
void fileSeperateVoid (std::vector<File*>& vecIn, std::vector<File*>& vecOut, std::string type);
void displayFileVoid (std::vector<File*>& files);

int main( )
{
    //creating a vector of file pointers called files
    std::vector<File*> files;

    //pushing 5 new file objects into files(3images, 2 text)
    files.push_back(new Image("TestOne", 1080, 19200, 1));
    files.push_back(new Text("TestTwo",44));
    files.push_back(new Image("TestThree", 2860, 1440, 8));
    files.push_back(new Text("TestFour",100));
    files.push_back(new Image("TestFive", 360, 360, 3));

    //Testing the first recursive function
    std::cout << "*****Testing displayFile function:*****\n" << std::endl;
    displayFile(files);

    //Testing the second recursive function
    std::cout << "*****Testing fileSeperate function:*****\n" << std::endl;
    displayFile(fileSeperate(files, "txt"));

    return 0;
}

//recursive function to help display all files in vector of files
void displayFile(const std::vector<File*>& files)
{
    //creates a temporary vector of file pointers
    std::vector<File*> tempVec(files);
    //calls displayFileVoid on tempVec
    displayFileVoid(tempVec);
}

//recursive function that helps display user entered type of file
std::vector<File*> fileSeperate(const std::vector<File*>& files, std::string type)
{
    //creates a temporary vector of file pointers
    std::vector<File*> tempVec(files), retVec;
    //calls fileSeperateVoid on tempVec
    fileSeperateVoid(tempVec, retVec, type);

    return retVec;
}

//recursive function that helps display user entered type of file
void fileSeperateVoid(std::vector<File*>& vecIn, std::vector<File*>& vecOut, std::string type)
{
    //if the vector input is not empty return
    if (vecIn.empty())
    {
        return;
    }
    //create a file pointer to the back of the file vector
    File* backFile = vecIn.back();
    //pop the object at the back of the file vector
    vecIn.pop_back();
    //call fileSeperateVoid function
    fileSeperateVoid(vecIn, vecOut, type);

    //if object at back of file is the same as user entered type push it to the destination vector
    if (backFile->getType() == type)
    {
        vecOut.push_back(backFile);
    }
}

//recursive function to help display all files in vector of files
void displayFileVoid(std::vector<File*>& files)
{
    //if vector parameter is not empty traverse from the back
    if (!files.empty())
    {
        //create a file pointer to the back of the file vector
        File* backFile = files.back();
        //pop the object at the back of the file vector
        files.pop_back();
        //call display file function
        displayFile(files);

        //if backfile is a gif file display its details
        if (backFile->getType() == "gif")
        {
            Image* imageFile = dynamic_cast<Image*>(backFile);
            std::cout << "File Name: " + imageFile->getName() + "\n" << "     Type: " + imageFile->getType() << "\n     Dimension: " << imageFile->getPixelColumn();
            std::cout << " X " << imageFile->getPixelRow() <<  "\n     Color Depth: " << imageFile->getColorDepth() << "\n     Size: " << imageFile->getSize() << " bytes\n" << std::endl;
        }
        //if backfile is a txt file display its details
        else
        {
            Text* textFile = dynamic_cast<Text*>(backFile);
            std::cout << "File Name: " + textFile->getName() + "\n" << "     Type: " + textFile->getType() << "\n     Size: " << textFile->getSize() << " bytes" << std::endl;
            std::cout << "     Character Count: " << textFile->getCharCount() <<  "\n" << std::endl;
        }
    }
}

